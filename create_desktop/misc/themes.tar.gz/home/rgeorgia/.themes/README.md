# openbox-themes
The best Openbox themes selected by me

# English
To see the image/screenshot of each theme, go to:
### [The 17 Best Themes for your Openbox](https://en.terminalroot.com.br/the-17-best-themes-for-your-openbox/)

---

# Português 
Para ver a imagem/captura de tela de cada um dos temas, acesse:
### [Os 17 Melhores Temas para seu Openbox](https://terminalroot.com.br/2021/11/os-17-melhores-temas-para-seu-openbox.html)

---
